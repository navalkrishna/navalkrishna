LYRIS WEBSITE — NETLIFY READY

HOW TO PUBLISH
1. Extract the ZIP file.
2. Open Netlify and choose Add new site > Deploy manually (or drag and drop the extracted folder into the deploy area).
3. Upload the folder that contains index.html, styles.css, script.js and the assets folder.

BEFORE GOING LIVE
1. Open script.js and replace WHATSAPP_NUMBER with the real WhatsApp number in international format, digits only. For India, use 91 followed by the mobile number.
2. In index.html, replace the placeholder tel:+910000000000 links with the real phone number.
3. Confirm the actual product sizes, product names, certifications and delivery coverage with the company before adding them. The current site intentionally avoids making unverified claims.
4. Add the company's real address, email and any required legal/company details if applicable.

FILES
- index.html: website content
- styles.css: responsive design and styling
- script.js: mobile navigation and WhatsApp link setup
- assets/lyris-hero.jpg: supplied LYRIS product photograph used in the hero background
- assets/lyris-logo.png: cropped LYRIS elephant logo for the header and footer

This is a static website; no build command or framework is required.


LATEST UPDATE
- Added LYRIS Instagram profile links in the header, contact section and footer:
  https://www.instagram.com/lyris__water/
- Expanded the About LYRIS section with brand story and Kerala identity.
- Included the 500 ml, 1 litre, 2 litre and 5 litre product range in the brand description.
- Brand copy avoids unverified claims about certifications, water source or treatment processes.
