const toggle=document.querySelector('.menu-toggle');
const nav=document.querySelector('.nav-links');
toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
nav.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{nav.classList.remove('open');toggle.setAttribute('aria-expanded','false');}));
document.querySelector('#year').textContent=new Date().getFullYear();
// Replace the placeholder phone number below with the company's WhatsApp number (country code + number, digits only).
const WHATSAPP_NUMBER='910000000000';
const WHATSAPP_MESSAGE=encodeURIComponent('Hello LYRIS, I would like to know more about your products.');
document.querySelectorAll('.whatsapp-link').forEach(link=>link.href=`https://wa.me/${WHATSAPP_NUMBER}?text=${WHATSAPP_MESSAGE}`);


// Product detail popups
const productDetails = {
  'two-litre': {
    title: '2 Litre Bottle',
    image: 'assets/lyris-bottle-single.jpg',
    alt: 'LYRIS 2 litre drinking water bottle',
    description: 'The LYRIS 2 litre bottle offers a convenient larger bottle size for everyday use. It is suitable for keeping at home, taking to work or sharing during the day. Contact our team for current availability and ordering information.'
  },
  'bottle-range': {
    title: '1 Litre & 500 ml Bottles',
    image: 'assets/lyris-bottles-range.jpg',
    alt: 'LYRIS 1 litre and 500 ml drinking water bottles',
    description: 'Choose the LYRIS bottle size that fits your day. The 1 litre bottle is a handy everyday option, while the 500 ml bottle is easy to carry when travelling, commuting or heading out. Contact us to ask about availability and supply.'
  },
  'five-litre': {
    title: '5 Litre Container',
    image: 'assets/lyris-family-pack.jpg',
    alt: 'LYRIS 5 litre water container',
    description: 'The LYRIS 5 litre container is designed for a larger water requirement in homes, small offices and shared spaces. Its larger capacity makes it a practical option when you want more drinking water available in one container. Contact our team for ordering and delivery details.'
  }
};
const productModal = document.querySelector('#product-modal');
const modalTitle = document.querySelector('#modal-title');
const modalDescription = document.querySelector('#modal-description');
const modalImage = document.querySelector('#modal-image');
let lastProductTrigger = null;
function openProductModal(key, trigger) {
  const item = productDetails[key];
  if (!item || !productModal) return;
  lastProductTrigger = trigger;
  modalTitle.textContent = item.title;
  modalDescription.textContent = item.description;
  modalImage.src = item.image;
  modalImage.alt = item.alt;
  productModal.classList.add('is-open');
  productModal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('modal-open');
  productModal.querySelector('.product-modal-close').focus();
}
function closeProductModal() {
  if (!productModal) return;
  productModal.classList.remove('is-open');
  productModal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('modal-open');
  if (lastProductTrigger) lastProductTrigger.focus();
}
document.querySelectorAll('.product-trigger').forEach(card => {
  card.addEventListener('click', () => openProductModal(card.dataset.product, card));
  card.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      openProductModal(card.dataset.product, card);
    }
  });
});
productModal?.querySelectorAll('[data-modal-close]').forEach(el => el.addEventListener('click', closeProductModal));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && productModal?.classList.contains('is-open')) closeProductModal();
});
